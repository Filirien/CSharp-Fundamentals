﻿namespace _07.Problem.Interfaces
{
    public interface IBuyer
    {
        int Food { get; }

        void BuyFood();
    }
}