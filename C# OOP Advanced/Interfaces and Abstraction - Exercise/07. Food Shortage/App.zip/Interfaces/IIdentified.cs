﻿namespace _07.Problem.Interfaces
{
    public interface IIdentified
    {
        string Name { get; }

        int Age { get; }
    }
}