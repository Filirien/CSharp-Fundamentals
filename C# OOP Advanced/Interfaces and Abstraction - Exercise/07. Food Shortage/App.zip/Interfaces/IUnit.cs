﻿namespace _07.Problem.Interfaces
{
    public interface IUnit : IBuyer, IIdentified
    {
    }
}