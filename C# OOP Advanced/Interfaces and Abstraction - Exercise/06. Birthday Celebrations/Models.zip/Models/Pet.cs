﻿namespace Interfaces_and_Abstraction.Models
{
    public class Pet : BiologicalUnit
    {
        public Pet(string name, string birthday)
            : base(name, birthday)
        {
        }
    }
}
