﻿using System.Data;

namespace Interfaces_and_Abstraction.Interfaces
{
    public interface IBorn
    {
        string Birthday { get; }
    }
}
