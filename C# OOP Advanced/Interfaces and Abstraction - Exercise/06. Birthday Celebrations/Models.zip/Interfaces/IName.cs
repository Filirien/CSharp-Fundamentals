﻿namespace Interfaces_and_Abstraction.Interfaces
{
    public interface IName
    {
        string Name { get; }
    }
}