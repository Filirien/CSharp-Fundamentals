﻿namespace Interfaces_and_Abstraction.Interfaces
{
    public interface IIdentified
    {
        string Id { get; }
    }
}